package Lab4.Exception;

public class AllDieException extends RuntimeException{
    public AllDieException(String description){
        super(description);
    }
}
