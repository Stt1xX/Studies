package Lab4.Exception;

public class NoPersonException extends Exception{
    public NoPersonException(String description){
        super(description);
    }
}
