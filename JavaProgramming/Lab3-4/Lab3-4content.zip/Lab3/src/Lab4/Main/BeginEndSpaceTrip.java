package Lab4.Main;

public interface BeginEndSpaceTrip {

    void description();
}
