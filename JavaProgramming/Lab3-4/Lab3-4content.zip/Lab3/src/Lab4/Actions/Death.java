package Lab4.Actions;

public interface Death {
    boolean die();
}
