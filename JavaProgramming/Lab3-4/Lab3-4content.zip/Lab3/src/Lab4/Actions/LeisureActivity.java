package Lab4.Actions;

public interface LeisureActivity {
    public void dosomething();
}
